package dodgenResQ;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.Range;

/**
 * Created by Afterburner 3 on 1/5/2016.
 */
public class
        BlueTankDriveMode extends OpMode {

    DcMotor motorPortRear, motorStarboardRear, motorPortFront, motorStarboardFront;
    DcMotor motorScore, motorPullUp;
    Servo servoPeople, servoBlueChute, servoRedChute;
    double servoPeoplePosition = 0;

    boolean isPullupEnabled = false;
    double lagConstDrive = 6.0;
    double rightPowerCurrent = 0.0;
    double leftPowerCurrent = 0.0;


    @Override
    public void init() {

        // Initialize motors for all the wheels
        motorPortFront = hardwareMap.dcMotor.get("motorPortFront");
        motorPortRear = hardwareMap.dcMotor.get("motorPortRear");
        motorStarboardRear = hardwareMap.dcMotor.get("motorStarRear");
        motorStarboardFront = hardwareMap.dcMotor.get("motorStarFront");
        // port side motors need to be reversed
        motorPortFront.setDirection(DcMotor.Direction.REVERSE);
        motorPortRear.setDirection(DcMotor.Direction.REVERSE);
        // Initialize the scoop and pull up motors
        motorScore = hardwareMap.dcMotor.get("motorScore");
        motorPullUp = hardwareMap.dcMotor.get("motorPullUp");

        servoPeople = hardwareMap.servo.get("servo3");
        servoPeople.setPosition(0);
        servoBlueChute = hardwareMap.servo.get("servoBlueChute");
        servoRedChute = hardwareMap.servo.get("servoRedChute");

        servoBlueChute.setPosition(1);
        servoRedChute.setPosition(0.0);

    }

    @Override
    public void loop() {
        handleGamePad1Controls();

        handleGamePad2Controls();
    }

    private void handleGamePad1Controls() {

        float left = -gamepad1.left_stick_y;
        float right = -gamepad1.right_stick_y;


        // clip the right/left values so that the values never exceed +/- 1
        right = Range.clip(right, -1, 1);
        left = Range.clip(left, -1, 1);

        setWheelMotorPowers(left, right);

    }


    private void handleGamePad2Controls() {

        double motorScorePower = gamepad2.left_stick_y;
        // motorScore.setPower(-smoothenMotorPower(motorScorePower) * .35);
        operateDebrisScooper(motorScorePower);
// .45 for speed decrease to 45% from 100%

        if (gamepad2.y) {
            dropClimbers();
        }

        if (gamepad2.x) {
            resetClimberServo();
        }

        if (gamepad2.b) {//score
            servoBlueChute.setPosition(0.40);
        }

        if (gamepad2.a) {//store
            servoBlueChute.setPosition(1);
        }
    }


    private void operateDebrisScooper(double leftThumbStickValue) {
        MotorUtils.operateScooper(motorScore, leftThumbStickValue);
    }

    private void dropClimbers() {
        servoPeoplePosition += 0.2;

        servoPeoplePosition = Range.clip(servoPeoplePosition, 0, 1);

        servoPeople.setPosition(servoPeoplePosition);
    }


    private void resetClimberServo() {
        servoPeople.setPosition(0);
    }


    private void setWheelMotorPowers(double leftPower, double rightPower) {

        //  Process the joystick value through your LUT algorithm just like before, then update like this:

        leftPower = smoothenMotorPower(leftPower);
        rightPower = smoothenMotorPower(rightPower);

        //rightPowerCurrent = (rightPowerCurrent * (lagConstDrive - 1.0) + rightPower) / lagConstDrive;
        // leftPowerCurrent = (leftPowerCurrent * (lagConstDrive - 1.0) + leftPower) / lagConstDrive;

        motorPortRear.setPower(leftPower);
        motorPortFront.setPower(leftPower);

        motorStarboardFront.setPower(rightPower);
        motorStarboardRear.setPower(rightPower);

    }

    // Smoothing function based on Old robotc article found on internet
    private double smoothenMotorPower(double originalValue) {

        // 0.90 is used as motor is usually at its maximum speed at 80% or more..
        // 0.10 is the minimum value at which motor starts running .. can adjust this based
        // on experiment on motors
        double smoothedValue = 0.0f;
        smoothedValue = (Math.pow(originalValue, 2) * 0.90 * (originalValue / Math.abs(originalValue))) + (0.10 * (originalValue / Math.abs(originalValue)));
        return smoothedValue;
    }

}
