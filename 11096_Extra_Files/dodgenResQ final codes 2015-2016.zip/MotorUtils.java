package dodgenResQ;

import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.util.Range;

/**
 * Created by Afterburner 3 on 1/17/2016.
 */
public class MotorUtils {


    public static void makeLeftTurn(HardwareMap hardwareMap) {
        _moveMotors(-0.35, 0.35, hardwareMap);
    }


    public static void makeRightTurn(HardwareMap hardwareMap) {
        _moveMotors(0.35, -0.35, hardwareMap);
    }


    public static void makePivotLeftTurn(HardwareMap hardwareMap) {
        _moveMotors(0, 0.35, hardwareMap);
    }

    public static void makePivotRightTurn(HardwareMap hardwareMap) {
        _moveMotors(0.35, 0, hardwareMap);
    }


    private static void _moveMotors(double portPower, double starboardPower, HardwareMap hardwareMap) {

        DcMotor motorPortRear, motorStarboardRear, motorPortFront, motorStarboardFront;

        motorPortFront = hardwareMap.dcMotor.get("motorPortFront");
        motorPortRear = hardwareMap.dcMotor.get("motorPortRear");
        motorStarboardRear = hardwareMap.dcMotor.get("motorStarRear");
        motorStarboardFront = hardwareMap.dcMotor.get("motorStarFront");

        motorPortFront.setPower(portPower);
        motorPortRear.setPower(portPower);
        motorStarboardFront.setPower(starboardPower);
        motorStarboardRear.setPower(starboardPower);

    }


    public static void operateScooper(DcMotor motorScore, double leftThumbstickValue) {
        if (leftThumbstickValue == 0.0) {
            // Scooper not being controlled..
            motorScore.setPower(0.0f);
            // just return for now..
        } else {

            leftThumbstickValue = -leftThumbstickValue;

            // ensure that the value is always between -1 and +1
            // to avoid motor burn out
            double clippedThumbStickValue = Range.clip(leftThumbstickValue, -1, 1);

            if (clippedThumbStickValue > 0) {
                motorScore.setDirection(DcMotor.Direction.FORWARD);
            } else {
                motorScore.setDirection(DcMotor.Direction.REVERSE);
            }

            // Don't allow scooper to sling shot with excessive power
            double clippedMotorPower = Range.clip(clippedThumbStickValue, -0.35f, 0.35f);

            motorScore.setPower(Math.abs(clippedMotorPower));
        }
    }
}
