package dodgenResQ;

//package com.qualcomm.ftcrobotcontroller.opmodes;

/*
instructions                    parameter
's' drive Straight encoder      distance in tiles
'g' gyro turn                   z angle to turn
't' drive straight touch        direction, motor speed scaling
'b' beacon press                TBD
'c' climber drop                TBD
'w' wait                        time to wait (ms)
'e' end
'r' reset encoders
 */

import com.qualcomm.hardware.modernrobotics.ModernRoboticsI2cGyro;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorController;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.TouchSensor;


/*
 *
 * This is autonomous LinearOpMode
 *
 */
public class autoInspection extends LinearOpMode {

    final static float MOTOR_POWER = (float) 0.60;
    final static float MOTOR_POWER_TURN = (float) 0.3;
    final static float SPEED_MIN = (float) 0.06; // min motor speed, straight drive
    final static float SPEED_MIN_TURN = (float) 0.08; // min motor speed, turning
    final static int ENCODER_TOLERANCE = 40;
    final static int ENCODER_ACCEL_CONST = 500;
    final static int GO_ONE_TILE_PORT = 3375;
    final static int GO_ONE_TILE_STAR = 3375;
    final static float GYRO_ACCEL_CONST = 15;
    final static int HEADING_TOLERANCE = 2;
    final static double SERVO_BLUE_CHUTE_DROP = 0.4;
    final static double SERVO_BLUE_CHUTE_HOLD = 1.0;
    final static double SERVO_RED_CHUTE_DROP = 1.0;
    final static double SERVO_RED_CHUTE_HOLD = 0.4;

    DcMotor motorPortRear, motorPortFront;
    DcMotor motorStarboardRear, motorStarboardFront;
    DcMotor motorScore;
    Servo servoPeople, servoRedChute, servoBlueChute;
    ModernRoboticsI2cGyro gyroSensor;
    TouchSensor portTouchSensor, starBoardTouchSensor;
    long startTime;

    @Override
    public void runOpMode() throws InterruptedException {

        String[] autoInstructions = {"wait","straight","wait","gyro", "straight",  "gyro","lift", "wait","lift","wait", "lift","touch","climber", "end"};
//      double[] autoParameter =    {    0 ,         2,     0,   -40,        1.8,    -40 ,  -0.4,      0, -0.45,     0,    0.3,   0.35,        1,     0};
        double[] autoParameter =    {    0 ,         2,     0,   -45,        1.8,    -45 ,  -0.25,      0, -0.25,     0,    0.3,   0.35,        1,     0};
        double[] autoTimeLimit =    { 1000 ,      4000,  6000,  3000,       3600,    3000,    400,    400,   450,   400,    600,   4000,     2000,     0};

        String currentInstruction;
        int instructionIndex = 0;
        double currentParameter;
        double currentTimeLimit;
        int numberOfInstructions;
        boolean doNextInstruction = false;
        boolean Terminate = false;

        int heading;
        float speedPort, speedStar;
        float portTarget, starTarget;
        double peopleDeploy = 1;
        double peopleStore  = 0;

        int ENCODER_PORT_RESET = 0;
        int ENCODER_STAR_RESET = 0;

        // write some device information (connection info, name and type)
        // to the log file.
        hardwareMap.logDevices();

        //  Use the hardwareMap to get the dc motors and servos by name.
        motorPortFront = hardwareMap.dcMotor.get("motorPortFront");
        motorPortRear = hardwareMap.dcMotor.get("motorPortRear");
        motorStarboardFront = hardwareMap.dcMotor.get("motorStarFront");
        motorStarboardRear = hardwareMap.dcMotor.get("motorStarRear");
        motorScore = hardwareMap.dcMotor.get("motorScore");

        //reverse the port motors
        motorPortFront.setDirection(DcMotor.Direction.REVERSE);
        motorPortRear.setDirection(DcMotor.Direction.REVERSE);

        servoPeople = hardwareMap.servo.get("servo3");
        servoRedChute = hardwareMap.servo.get("servoRedChute");
        servoBlueChute = hardwareMap.servo.get("servoBlueChute");
        portTouchSensor = hardwareMap.touchSensor.get("portTouch");
        starBoardTouchSensor = hardwareMap.touchSensor.get("starBoardTouch");// touch sensor

        // motor encoder mode - encoders only work in "RUN_WITHOUT_ENCODERS"
        motorStarboardFront.setMode(DcMotorController.RunMode.RUN_WITHOUT_ENCODERS);
        motorStarboardRear.setMode(DcMotorController.RunMode.RUN_WITHOUT_ENCODERS);

        // get a reference to our GyroSensor object.
        //gyroSensor = hardwareMap.gyroSensor.get("gyroSensor");
        gyroSensor = (ModernRoboticsI2cGyro) hardwareMap.gyroSensor.get("gyroSensor");

        // calibrate the gyro.
        gyroSensor.calibrate();

        // initialize the instructions
        numberOfInstructions = autoInstructions.length;
        currentInstruction = autoInstructions[0];
        currentParameter = autoParameter[0];
        currentTimeLimit = autoTimeLimit[0];

        // reset encoders
        ENCODER_PORT_RESET = motorPortRear.getCurrentPosition();
        ENCODER_STAR_RESET = motorStarboardFront.getCurrentPosition();

        // reset gyro heading.
        gyroSensor.resetZAxisIntegrator();

      //  servoBlueChute.setPosition(SERVO_BLUE_CHUTE_HOLD);  // Commented for inspection only
      //  servoRedChute.setPosition(SERVO_RED_CHUTE_HOLD);   // Commented for inspection only
       // servoPeople.setPosition(peopleStore); // Commented for inspection only
        // wait for the start button to be pressed.
        waitForStart();

        // make sure the gyro is done calibrating
        while (gyroSensor.isCalibrating())  {
            Thread.sleep(50);
        }
        startTime = System.currentTimeMillis();
        while (opModeIsActive() && (!Terminate))  {

            switch (currentInstruction) {
                case "straight":      //  drive straight using encoders
                    telemetry.addData("Text", "Straight");
                    portTarget = (float)currentParameter * GO_ONE_TILE_PORT;
                    //starTarget = (float)currentParameter * GO_ONE_TILE_STAR;

                    if ((Math.abs(motorPortRear.getCurrentPosition()-ENCODER_PORT_RESET) < Math.abs(portTarget) - ENCODER_TOLERANCE) )// ||
                      //      (Math.abs(motorStarboardFront.getCurrentPosition()-ENCODER_STAR_RESET) < Math.abs(starTarget) - ENCODER_TOLERANCE))
                    // disabled starboard encoder since the two were not in sync
                    {
                        // speed is proportional to number of encoder steps away from target
                        speedPort = MOTOR_POWER / ENCODER_ACCEL_CONST * (portTarget - (motorPortRear.getCurrentPosition()-ENCODER_PORT_RESET));
                        speedStar = speedPort;
                        //speedStar = MOTOR_POWER / ENCODER_ACCEL_CONST * (starTarget - (motorStarboardFront.getCurrentPosition()-ENCODER_STAR_RESET));

                        // don't go faster than SPEED_NOMINAL
                        speedPort = Math.signum(speedPort) * Math.min(Math.abs(speedPort), MOTOR_POWER);
                        speedStar = Math.signum(speedStar) * Math.min(Math.abs(speedStar), MOTOR_POWER);

                        // don't go slower than SPEED_MIN
                        speedPort = Math.signum(speedPort) * Math.max(Math.abs(speedPort), SPEED_MIN);
                        speedStar = Math.signum(speedStar) * Math.max(Math.abs(speedStar), SPEED_MIN);

                        // set the motor speeds
                        motorStarboardRear.setPower(speedStar);
                        motorStarboardFront.setPower(speedStar);
                        motorPortRear.setPower(speedPort);
                        motorPortFront.setPower(speedPort);
                    }
                    else{
                        motorStarboardFront.setPower(0.0);
                        motorStarboardRear.setPower(0.0);
                        motorPortFront.setPower(0.0);
                        motorPortRear.setPower(0.0);
                        //currentInstruction="gyro";//straighten out
                        //currentParameter=0;
                        //currentTimeLimit=2000;
                        //startTime = System.currentTimeMillis();
                        doNextInstruction=true;
                    }
                    break;
                case "gyro":      //  gyro turn
                    telemetry.addData("Text", "Gyro");
                    heading = gyroSensor.getIntegratedZValue(); // getIntegratedZValue() works for any turn angle
                    if ( (Math.abs(heading) < (Math.abs(currentParameter)-HEADING_TOLERANCE)) && (elapsedTime() < currentTimeLimit))
//                    if ( (Math.abs(heading) < (Math.abs(currentParameter)-HEADING_TOLERANCE)) )
                        {
                        // speed is proportional to angle away from target
                        speedPort = (float)(MOTOR_POWER / GYRO_ACCEL_CONST * (currentParameter - heading));
                        // don't go faster than SPEED_NOMINAL
                        speedPort = Math.signum(speedPort) * Math.min(Math.abs(speedPort), MOTOR_POWER_TURN);
                        // don't go slower than SPEED_MIN
                        speedPort = Math.signum(speedPort) * Math.max(Math.abs(speedPort), SPEED_MIN_TURN);

                        // set the speeds
                        motorStarboardFront.setPower(-speedPort);
                        motorStarboardRear.setPower(-speedPort);
                        motorPortFront.setPower(speedPort);
                        motorPortRear.setPower(speedPort);
                    }
                    else{
                        motorStarboardFront.setPower(0.0);
                        motorStarboardRear.setPower(0.0);
                        motorPortFront.setPower(0.0);
                        motorPortRear.setPower(0.0);
                        Thread.sleep(50);
                        doNextInstruction = true;
                    }
                    break;
                case "touch":	   //  go straight using touch sensor
                    telemetry.addData("Text", "Touch");
                    if(portTouchSensor.isPressed () || starBoardTouchSensor.isPressed()) {
                        driveStop();
                        Thread.sleep(200); // give time to stop motors
                        doNextInstruction = true;
                    }
                    else {
                        //drive
                        motorStarboardFront.setPower(currentParameter*MOTOR_POWER);
                        motorStarboardRear.setPower(currentParameter*MOTOR_POWER);
                        motorPortFront.setPower(currentParameter*MOTOR_POWER);
                        motorPortRear.setPower(currentParameter*MOTOR_POWER);
                    }
                    if(elapsedTime()>=currentTimeLimit)
                    {
                        driveStop();
                        //currentInstruction="gyro";
                        //currentParameter=0;
                        //currentTimeLimit=2000;
                        //startTime = System.currentTimeMillis();
                        doNextInstruction=true;
                    }
                    break;
                case "lift":      //  raise and lower the scoop
                    motorScore.setPower(currentParameter);
                    if(elapsedTime()>=currentTimeLimit)
                    {
                        doNextInstruction = true;
                        motorScore.setPower(0);
                    }
                    break;
                case "climber":      //  climber in bin
                    telemetry.addData("Text", "Climber");
                    servoPeople.setPosition(peopleDeploy);
                    Thread.sleep(1050); // give time to stop
                    servoPeople.setPosition(peopleStore);
                    Thread.sleep(300);
                    doNextInstruction = true;
                    break;
                case "resetEncoder":      //  reset encoder
                    telemetry.addData("Text", "Reset Encoder");
                    ENCODER_PORT_RESET = motorPortRear.getCurrentPosition();
                    ENCODER_STAR_RESET = motorStarboardFront.getCurrentPosition();
                    //Thread.sleep(200);
                    doNextInstruction = true;
                    break;
                case "timeGo":      //  reset encoder
                    telemetry.addData("Text", "Time Go");
                    motorStarboardRear.setPower(currentParameter);
                    motorStarboardFront.setPower(currentParameter);
                    motorPortRear.setPower(currentParameter);
                    motorPortFront.setPower(currentParameter);
                    if(elapsedTime()>=currentTimeLimit)
                    {
                        driveStop();
                        doNextInstruction = true;
                    }
                    break;
                case "wait":      //  wait
                    telemetry.addData("Text", "Waiting");
                    if(elapsedTime()>=currentTimeLimit)
                    {
                        doNextInstruction = true;
                    }
                    driveStop(); // added for failproof stopping
                    break;
                case "end":      //  end
                    telemetry.addData("Text", "End");
                    Terminate = true;
                    break;
                default:       //  if instructions don't work, or the code is done, we wait for the rest of eternity, or not...
                    telemetry.addData("Text", "Bad instruction");
                    Terminate = true;
                    break;
            }

            if(doNextInstruction)
            {
                instructionIndex++;
                if(instructionIndex>=numberOfInstructions)
                {// catch if the last instruction just finished
                    Terminate = true;
                }
                else {
                    // load next instruction
                    currentParameter = autoParameter[instructionIndex];
                    currentInstruction = autoInstructions[instructionIndex];
                    currentTimeLimit = autoTimeLimit[instructionIndex];
                    // reset encoders
                    ENCODER_PORT_RESET = motorPortRear.getCurrentPosition();
                    ENCODER_STAR_RESET = motorStarboardFront.getCurrentPosition();
                    // reset gyro heading. UNTESTED
                    gyroSensor.resetZAxisIntegrator();
                    // reset start time
                    startTime = System.currentTimeMillis();
                }
                doNextInstruction = false; // reset doNextInstruction for the next step
            }

            telemetry.addData("gyro rotation ", gyroSensor.getIntegratedZValue());
            telemetry.addData("Port encoder ", motorPortRear.getCurrentPosition()-ENCODER_PORT_RESET);
            telemetry.addData("Star encoder ", motorStarboardFront.getCurrentPosition() - ENCODER_STAR_RESET);
            waitOneFullHardwareCycle();
        }
    }

    private void driveStop() {

        motorPortFront.setPower(0);
        motorPortRear.setPower(0);
        motorStarboardFront.setPower(0);
        motorStarboardRear.setPower(0);
    }

    private long elapsedTime() {

        return System.currentTimeMillis() - startTime;
    }

}
